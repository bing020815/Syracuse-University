# Clean data
  
label: `pos=1`   `neg=0`  